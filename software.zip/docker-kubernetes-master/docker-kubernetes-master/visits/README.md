# How to run this project

build docker container
~~~
docker build -t daun/visits:latest .
~~~


run docker
~~~
docker-compose up --build
~~~

